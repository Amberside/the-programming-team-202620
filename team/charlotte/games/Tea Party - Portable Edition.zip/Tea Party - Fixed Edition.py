import winsound
import sys
import threading
import time as time_module
import os
import subprocess

subprocess.check_call([
    sys.executable, "-m", "pip", "install", 
    "--no-index", 
    "offline_packages\\pynput-1.8.2-py2.py3-none-any.whl", "offline_packages\\six-1.17.0-py2.py3-none-any.whl"
])

from pynput.keyboard import Key, Listener

One = False
Two = False
Three = False
Four = False
Five = False

SecretMeter = 0
WorthItUnlocked = False

time_left = 0
timer_on = False
intro = False
game_running = True
introNotSkipped = False

def on_press(key):
    global intro
    
    if key == Key.enter:
        intro = False

listener = Listener(on_press=on_press)
listener.start()

def clear_screen():
    if os.name == 'nt':
        subprocess.run('cls', shell=True)
    else:
        subprocess.run(['clear'])

def type_text(text, delay=0.08, stop_on_intro=False):
    for char in text:
        if stop_on_intro and not intro:
            return

        sys.stdout.write(char)
        sys.stdout.flush()
        time_module.sleep(delay)

    print()


def wait_for_enter(prompt="Press Enter to continue..."):
    input(prompt)

def wait_for_enter_no_prompt():
    input()


def reset_game_state():
    global One, Two, Three, Four, Five
    global SecretMeter, WorthItUnlocked
    global time_left, timer_on, intro, introNotSkipped

    One = False
    Two = False
    Three = False
    Four = False
    Five = False
    SecretMeter = 0
    WorthItUnlocked = False
    time_left = 0
    timer_on = False
    intro = False
    introNotSkipped = True

def countdown(seconds):
    global time_left, timer_on

    time_left = seconds
    timer_on = True

    while timer_on and time_left > 0:
        time_module.sleep(1)
        time_left -= 1

    timer_on = False


def stop_timer():
    global timer_on
    timer_on = False

def no_input():
    global introNotSkipped
    introNotSkipped = True

def timed_out():
    return time_left <= 0

def gameover():
    stop_timer()
    clear_screen()

    type_text(
        "You ran out of time.\n"
        "The guests arrive and see the mess, they leave and never come back.\n",
        0.185
    )

    clear_screen()
    type_text("End 7 of 8: Out of Time.\n", 0.085)
    wait_for_enter()
    clear_screen()
    kettle_choice_1()

def intro_scene():
    global intro, time_left, introNotSkipped

    clear_screen()

    intro = True
    time_left = 11

    intro_timer = threading.Thread(
        target=countdown,
        args=(11,),
        daemon=True
    )
    intro_timer.start()

    type_text(
    "[INTRO]\n\nPress [ENTER] to skip intro.\n",
    0.08,
    True
    )

    type_text(
        "You have just moved to Britain and overhear that your neighbours "
        "are coming over for a tea party, apparently all british people do "
        "this and it's seen as rude not to, they are arriving today",
        0.08,
        True
    )

    type_text("...\n", 0.3, True)
    type_text("Like, in 90 seconds", 0.08, True)
    type_text("...\n", 0.3, True)
    type_text("Starting right now.", 0.08, True)

    if not intro:
        introNotSkipped = False
        return

    introNotSkipped = True
    intro = False
    stop_timer()
    
def kettle_choice_1():
    global One, SecretMeter

    winsound.PlaySound("90 Second Dash.wav", winsound.SND_ASYNC | winsound.SND_LOOP)

    timer_thread = threading.Thread(
        target=countdown,
        args=(90,),
        daemon=True
    )
    timer_thread.start()

    while time_left > 0:
        clear_screen()

        if introNotSkipped == False:
            wait_for_enter_no_prompt()
            clear_screen()
            
        kettle1 = input(
            "Do you turn the kettle on?\n"
            "1. Yes\n"
            "2. No\n\n"
        ).strip()

        if timed_out():
            gameover()
            return

        if kettle1 == "1":
            type_text("You turn the kettle on.\n", 0.085)

            if timed_out():
                gameover()
                return

            wait_for_enter()
            clear_screen()
            cookie_choice_1()
            return
        
        elif kettle1 == "2":
            type_text(
                "You start procrastinating, so you decide to rethink your "
                "life chioces and pick up a job for web design instead.\n",
                0.085
            )

            clear_screen()
            type_text(
                "End 1 of 8: Mid-Life Crisis.\n",
                0.085
            )

            wait_for_enter()
            clear_screen()
            no_input()
            kettle_choice_1()
            return

        else:
            type_text(
                "Due to your incompetency to make a *VALID* choice, "
                "you instead start dancing on the floor",
                0.085
            )
            type_text("...\n", 0.3)

            clear_screen()
            type_text("End ??? of 8: ", 0.3)

            if not One:
                SecretMeter += 1
                One = True

            winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)
            input("BINGUS")
            no_input()
            clear_screen()
            kettle_choice_1()
            return

    gameover()

def cookie_choice_1():
    global Two, SecretMeter

    cookie1 = input(
        "Do you grab the cookie tin?\n"
        "1. Yes\n"
        "2. No\n\n"
    ).strip()

    if timed_out():
        gameover()
        return

    if cookie1 == "1":
        type_text("You grab the cookie tin.\n\n", 0.085)

        if timed_out():
            gameover()
            return

        wait_for_enter()
        clear_screen()
        cookie_choice_2()

    elif cookie1 == "2":
        type_text(
            "You start thinking that maybe inviting people over for tea is "
            "a horrible idea, '*MAYBE THEY'RE MURDERERS*' you tell yourself.\n",
            0.08
        )
        type_text("wait\n", 0.2)
        type_text("...\n", 0.3)

        type_text(
            "They already know your address!! Maybe they kidnap you? What if "
            "they steal your life savings? Will they rob you? Who knows? I know! "
            "Do you know? Oh no what if they eat you alive, or bury you alive? "
            "You have to run, burn down your house, change your name, live in "
            "isolation in the forest",
            0.005
        )

        type_text("...\n", 0.1)

        type_text(
            "NO THE MOON, Yes! IT'S PERFECT, A PERFECT PLAN, YOU MUST ENACT IT NOW! "
            "GO GO GO GO GO GO!!!11!!!1111!11!1\n",
            0.005
        )

        clear_screen()
        type_text(
            "End 2 of 8: The Crazy Person That Lives in the Forest.\n",
            0.085
        )

        wait_for_enter()
        clear_screen()
        no_input()
        kettle_choice_1()

    else:
        type_text(
            "Due to your incompetency to make a *VALID* choice, you instead "
            "start breakdancing on the floor",
            0.085
        )
        type_text("...\n", 0.3)

        clear_screen()
        type_text("End ??? of 8: ", 0.3)

        if not Two:
            SecretMeter += 1
            Two = True

        winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)
        input("BINGUS")
        no_input()
        clear_screen()
        kettle_choice_1()

def cookie_choice_2():
    global Three, SecretMeter

    while True:
        cookie2 = input("How Many Cookies do you grab?\n\n").strip()

        if timed_out():
            gameover()
            return

        if "-" in cookie2:
            type_text("You grab " + cookie2 + " cookies.\n", 0.085)
            type_text("Wait", 0.185)
            type_text("...\n", 0.3)
            type_text(
                "A black hole forms and all your atoms get pulled into it.\n",
                0.001
            )

            clear_screen()
            type_text(
                "Ending 3 of 8: Gone Before You Even Realised.\n\n",
                0.085
            )

            if timed_out():
                gameover()
                return

            wait_for_enter()
            clear_screen()
            continue

        if cookie2.isdigit():
            number = int(cookie2)

            if number == 0:
                type_text(
                    "You decide that you don't want your guests to have any cookies.\n"
                    "'I'm not being selfish!', you tell yourself.\n"
                    "'They are!', you continue.\n",
                    0.08
                )

                type_text(
                    "'Thinking they can come to MY house, eat MY food and use MY "
                    "appliences!! Well, NO! They cannot! In fact, They don't even "
                    "deserve kindness! NOT if they're wanting to eat MY cookies! "
                    "In fact, they don't even deserve sunlight!'\n",
                    0.035
                )

                type_text(
                    "'YEAH, NO SUNLIGHT, IT'S ONLY MINE NOW!!!'\n",
                    0.025
                )

                type_text(
                    "'MINE MINE MINE IMINE MIEN MINE MNINE MNIE MINE MNI E MIE "
                    "MIJNEIMIIEM IMEINIE \nMEINFEFJFGIFOPVFODKF'\n",
                    0.005
                )

                clear_screen()
                type_text(
                    "End 4 of 8: You Absorbed the Sun and Now the Earth is Shrouded in Darkness.\n",
                    0.085
                )

                wait_for_enter()
                clear_screen()
                no_input()
                kettle_choice_1()
                return

            elif 1 <= number <= 4:
                type_text(
                    "You tell yourself that it's good to be cautious and "
                    "conservative with food. But it's no use, you decide to "
                    "rethink how many cookies you want to give.\n",
                    0.085
                )

                if timed_out():
                    gameover()
                    return

                wait_for_enter()
                clear_screen()
                continue

            elif 26 <= number <= 999:
                type_text(
                    "You tell yourself that perhaps it's good to be cautious "
                    "and conservative with food. You decide to rethink how "
                    "many cookies you want.\n",
                    0.085
                )

                if timed_out():
                    gameover()
                    return

                wait_for_enter()
                clear_screen()
                continue

            elif 5 <= number <= 25:
                type_text(
                    "You grab " + cookie2 + " cookies for your guests.\n",
                    0.085
                )

                wait_for_enter()
                clear_screen()
                kettle_choice_2()
                return

        type_text(
            "Due to your incompetency to make a *VALID* choice, you instead "
            "start breaking the floor",
            0.085
        )
        type_text("...\n", 0.3)

        clear_screen()
        type_text("End ??? of 8: ", 0.3)

        if not Three:
            SecretMeter += 1
            Three = True

        winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)
        input("BINGUS")
        no_input()
        clear_screen()
        kettle_choice_1()
        return

def kettle_choice_2():
    global Four, SecretMeter

    cookie1 = input(
        "Do you turn off the kettle?\n"
        "1. Yes\n"
        "2. No\n\n"
    ).strip()

    if timed_out():
        gameover()
        return

    if cookie1 == "1":
        type_text("You turn off the kettle.\n\n", 0.085)

        if timed_out():
            gameover()
            return

        wait_for_enter()
        clear_screen()
        make_tea()

    elif cookie1 == "2":
        type_text(
            "You don't care about safety! You're fearless! You're... BRAVE! Nothing tells "
            "you what to do!\n",
            0.08
        )
        type_text("Not even that smoke alarm? :)\n", 0.1)
        type_text("...", 0.15)

        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')
        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')
        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')

        type_text("I mean, what's it going to do?\n", 0.08)
        type_text(
            "Is a *kettle* going to burn my house down?\nHA\nDOUBT IT!\n",
            0.07
        )

        clear_screen()
        type_text("End 5 of 8: ", 0.08)
        type_text("The Kettle Burnt Your House Down.\n", 0.02)

        wait_for_enter()
        clear_screen()
        no_input()
        kettle_choice_1()

    else:
        type_text(
            "Due to your incompetency to make a *VALID* choice, "
            "you instead break the floor",
            0.085
        )
        type_text("...\n", 0.3)

        clear_screen()
        type_text("End ??? of 8: ", 0.3)

        if not Four:
            SecretMeter += 1
            Four = True

        winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)
        input("BINGUS")
        no_input()
        clear_screen()
        kettle_choice_1()

def make_tea():
    global Five, SecretMeter, WorthItUnlocked

    tea = input(
        "Do you make the tea?\n"
        "1. Yes\n"
        "2. No\n\n"
    ).strip()

    if timed_out():
        gameover()
        return

    if tea == "1":
        type_text("You make the tea.\n\n", 0.085)

        if timed_out():
            gameover()
            return

        wait_for_enter()
        clear_screen()
        finish()

    elif tea == "2":
        type_text(
            "You realise that you don't even like tea, you prefer coffee.\n",
            0.08
        )
        type_text(
            "How could you forget this?\nYou go on and on about how crap tea "
            "is compared to coffee *ALL* the time!\n",
            0.08
        )
        type_text("...", 0.3)

        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')

        type_text("Well apparently your guests don't think so", 0.08)
        type_text("...\n", 0.15)
        type_text(
            "Because they get so insulted by your statements, that they throw "
            "you off a boat!\n",
            0.08
        )

        clear_screen()
        type_text("End 6 of 8:", 0.08)
        type_text(
            "Why Would You Say That to British People?!\n",
            0.08
        )

        wait_for_enter()
        clear_screen()
        no_input()
        kettle_choice_1()

    else:
        if not Five:
            SecretMeter += 1
            Five = True

        if SecretMeter == 5:
            type_text(
                "Due to your incompetency to make a *VALID* choice, you instead "
                "find riches underneath your floor",
                0.085
            )
            type_text("...\n", 0.30)
            type_text("WORTH IT! \n\n", 0.08)

            winsound.PlaySound("YAY.wav", winsound.SND_ASYNC)
            input("You Unlocked a New Achievement: Worth It.\n")

            WorthItUnlocked = True
            clear_screen()
            finish()

        else:
            type_text(
                "Due to your incompetency to make a *VALID* choice, you instead "
                "go into a ",
                0.085
            )
            type_text("BREAKDANCE FRENZY", 0.1)
            type_text("YAAAYYYY!\n", 0.40)

            clear_screen()
            type_text("End ??? of 8.\n", 0.08)
            winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)
            input("BINGUS")
            no_input()
            clear_screen()
            kettle_choice_1()

def finish():
    if WorthItUnlocked:
        winsound.PlaySound("90 Second Dash.wav", winsound.SND_ASYNC)
        type_text(
            "With your newfound riches, you and your 4 british friends have "
            "a wonderful tea party filled with Lamborghinis!!\n",
            0.08
        )
        type_text(
            "End SECRET of 8: I Honestly Prefer Ferraris if I'm Going to be Honest.\n\n",
            0.08
        )
    else:
        type_text(
            "With your tea party completely set up, you and your 4 british "
            "friends have a wonderful tea party!\n",
            0.08
        )
        type_text(
            "End 8 of 8: Well That Was Easy!\n\n",
            0.08
        )
        type_text(
            "But try and find the secret ending!\n\n",
            0.08
        )

    stop_timer()

    try_again = input(
        "Do you want to play again?\n"
        "1. Yes\n"
        "2. No\n\n"
    ).strip()

    if try_again == "1":
        reset_game_state()
        clear_screen()
        kettle_choice_1()

    elif try_again == "2":
        clear_screen()
        print("Thanks for playing!")
        wait_for_enter()
        return

    else:
        type_text("Sorry, no secrets here.\n", 0.08)
        type_text("Unless", 0.12)
        type_text("...\n", 0.3)

        clear_screen()
        winsound.PlaySound("Incompetence.wav", winsound.SND_ASYNC)

        for _ in range(8):
            input("BINGUS")

        winsound.PlaySound("90 Second Dash.wav", winsound.SND_ASYNC)
        clear_screen()

        finish()

def main():
    reset_game_state()

    intro_scene()

    clear_screen()
    kettle_choice_1()


if __name__ == "__main__":
    main()
